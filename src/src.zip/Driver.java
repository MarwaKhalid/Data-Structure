
public class Driver {
	public static void main(String[] args) {
		MyPQSortedList<Integer, Integer> no = new MyPQSortedList<Integer, Integer>();
		no.insert(10, 11);
		no.insert(7, 11);
		no.insert(8, 11);
		no.display();
		System.out.println();
		no.insert(9, 11);
		no.display();

	}
}
